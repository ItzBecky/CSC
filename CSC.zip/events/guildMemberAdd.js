module.exports = (client, member) => {
  const defaultChannel = member.guild.channels.find(channel => channel.permissionsFor(guild.me).has('SEND_MESSAGES'));
  defaultChannel.send(`:cstick: ${member.name} joined the ${guild.name}! Please be sure to read <#565814957283868692> before you do anything else! :cstick:`).catch(console.error);
}