module.exports = (client, member) => {
  const defaultChannel = member.guild.channels.find(channel => channel.permissionsFor(guild.me).has('SEND_MESSAGES'));
  defaultChannel.send(`:cscross: ${member.name} left the ${guild.name}! So that means we can invite more! :cscross:`).catch(console.error);
}